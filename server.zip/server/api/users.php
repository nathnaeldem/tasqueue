<?php
require 'db.php';

// Endpoint to get list of staff members for manual assignment
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT id, name, email FROM users WHERE role = 'staff'");
    echo json_encode(['success' => true, 'users' => $stmt->fetchAll()]);
}
?>
