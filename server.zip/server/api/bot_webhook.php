<?php
require 'db.php';

// Bot Token
$botToken = '8288585533:AAENfZ1Qo2sCtZGq_WjcRLnqRVU1DjAopPg'; 
$apiUrl = "https://api.telegram.org/bot{$botToken}/";

// Receive Update
$content = file_get_contents("php://input");
$update = json_decode($content, true);

if (!$update) {
    exit;
}

if (isset($update['message'])) {
    $chatId = $update['message']['chat']['id'];
    $text = trim($update['message']['text'] ?? '');
    
    // Live Deployment URL
    $webAppUrl = "https://lemikura.x10.network/telegram-login";

    if ($text === '/start') {
        $keyboard = [
            'keyboard' => [
                [
                    [
                        'text' => '📱 Login to Lemikura', 
                        'web_app' => ['url' => $webAppUrl] 
                    ]
                ]
            ],
            'resize_keyboard' => true
        ];
        
        sendMessage($chatId, "Welcome! Click the button below to link your account.", $keyboard);
    }
}

function sendMessage($chatId, $text, $keyboard = null) {
    global $apiUrl;
    $postData = ['chat_id' => $chatId, 'text' => $text];
    if ($keyboard) {
        $postData['reply_markup'] = json_encode($keyboard);
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl . "sendMessage");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}
?>
