<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_GET['action'] ?? '';

    if ($action === 'register') {
        $name = $data['name'];
        $email = $data['email'];
        $password = $data['password'];
        // Default register as staff
        $role = 'staff'; 

        $hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $hash, $role]);
            echo json_encode(['success' => true, 'message' => 'User registered successfully']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => 'Registration failed: ' . $e->getMessage()]);
        }
    } elseif ($action === 'login') {
        $email = $data['email'];
        $password = $data['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            http_response_code(401);
            echo json_encode(['success' => false, 'error' => 'User not found']);
        } elseif (!password_verify($password, $user['password_hash'])) {
            http_response_code(401);
            echo json_encode(['success' => false, 'error' => 'Invalid password']);
        } else {
            // In a real app, use JWT. specific session for now.
            unset($user['password_hash']);
            echo json_encode(['success' => true, 'user' => $user]);
        }
    }
}
?>
